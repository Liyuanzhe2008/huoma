<?php
header("Content-type:application/json");
session_start();
if(isset($_SESSION["huoma.admin"])){

// 数据库配置
require_once("../MySql.php");

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 获得表单POST过来的数据
$title = $_POST["title"];

$hm_id = rand(10000,99999);

// 当前时间
$date = date("Y-m-d G:H:s");
// 插入数据库
		$sql = "INSERT INTO qun_huoma (title,hm_id) VALUES ('$title', '$hm_id')";

if ($conn->query($sql) === TRUE) {
$result = array(
"result" => "100",
"msg" => "添加成功"
);
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
$result = array(
"result" => "106",
"msg" => "添加失败，请检查数据库配置是否正确"

);
}

$conn->close();
}
// 返回结果
echo json_encode($result,JSON_UNESCAPED_UNICODE);

?>


