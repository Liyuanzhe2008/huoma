<?php
$servername = "127.0.0.1";//数据库地址
$username = "";//数据库账号
$password = "";//数据库密码
$dbname = "";//数据库名

// 后台账号密码
$adminusername = "admin";
$adminpassword = "admin123456";


?>
